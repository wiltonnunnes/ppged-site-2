<?php
class REST_Controller {
	
	public function post($data) {

	}
}